import { Component, OnInit , Input} from '@angular/core';
import { Hero } from '../hero';
import { HeroesComponent } from '../heroes/heroes.component';
import { HeroService } from '../hero.service';
import { SearchService } from '../services/search.service';


@Component({
  selector: 'app-hero-detail',
  templateUrl: './hero-detail.component.html',
  styleUrls: ['./hero-detail.component.css']
})

export class HeroDetailComponent implements OnInit {

  @Input()
  hero : Hero;
  term : string;
  loading : boolean = false;
  
  constructor( private searchService: SearchService) {}

  ngOnInit() {
    this.search('Martin Garrix');
  }

  search(term: string){
    this.loading = true;
    console.log(term +' searched');
    this.searchService.search(term).then( () => this.loading = false);
  }

}
