import { Component } from '@angular/core';
import { HeroesComponent } from './heroes/heroes.component';
import { Hero } from './hero';
import { EventEmitter } from '@angular/core/src/event_emitter';
import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { HeroService } from './hero.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  
  apiRoot: string = "http://httpbin.org";

  constructor(private http: Http, private heroService: HeroService) { 
    this.heroService.open.subscribe(
      data => {
        this.superHero = data;
      }
    );
  }

  superHero: Hero;

  getSuperHero(hero: Hero){
    this.superHero = hero;
  }
  
  doGET() {
    console.log("GET");
    let url = `${this.apiRoot}/get`;
    this.http.get(url).subscribe(res => console.log(res.json())); 
  }

}
